package com.apiTest;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.*;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;
import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

public class SampleAPITest {
	WebDriver driver;

	@Test
	public void apiResponse() {
		RestAssured.baseURI = "https://api.nasa.gov";

		Response resp = given().relaxedHTTPSValidation().param("api_key", "ovZAPvor2KLIkiqvcIneWBTisGpJeZgmbIYRxxEh")
				.when().get("/planetary/apod").then().body("$", hasKey("date")).extract().response();
		System.out.println("1. Passed API_KEY as query parameter for the API");

		// Validating response code
		if (resp.getStatusCode() == 200) {
			System.out.println("2. Got 200 status code of response with Date field");
		} else {
			System.out.println("Error!! Not working");
		}

		String formattedResp = resp.asString();
		// Convert response to JSON
		JsonPath js = new JsonPath(formattedResp);

		// Validating response parameter url & hdurl
		String strUrl = js.get("url");
		String strHdurl = js.get("hdurl");
		if (strUrl.equals(strHdurl)) {
			System.out.println("Error!! Response parameters - Url and Hdurl are same");
		} else {
			System.out.println("3. Success!! Response parameters - Url and Hdurl are different");
		}

		// Bonus
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\sai\\eclipseKosmikHMS\\SampleNasaAPI\\chromedriver.exe");

		driver = new ChromeDriver();
		driver.get("https://apod.nasa.gov/apod/astropix.html");
		driver.manage().window().maximize();

		String strWebImageUrl = driver.findElement(By.xpath("/html/body/center[1]/p[2]/a/img")).getAttribute("src");

		if (strUrl.equals(strWebImageUrl)) {
			System.out.println("4. (Bonus)Success!! API image matches with webpage image");
		} else {
			System.out.println("API image doesn't matches with webpage image");
		}
	}
}
