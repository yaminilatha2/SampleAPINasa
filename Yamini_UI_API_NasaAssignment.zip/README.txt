Note: Install Maven & integrate with Eclipse if not done.
Please wait till all dependencies are downloaded once pom.xml is imported.

UI testing
---------------
1. Import maven project from "SampleNasaTest" folder.
2. If any issues with chromedriver, download the latest one(.exe) and place in project path in eclipse.
3. In src/test/java >> com.sentry >> TestSentry.java, in line 17, change the path of chrome driver accordingly.
4. Import java 8 JRE library if not selected by default.
5. Run testng.xml
6. For simplicity, reports are displayed in console itself.


API testing
---------------
1. Import maven project from "SampleNasaAPI" folder.
2. If any issues with chromedriver, download the latest one(.exe) and place in project path in eclipse.
3. In src/test/java >> com.apiTest >> SampleAPITest.java, in line 46, change the path of chrome driver accordingly.
4. Import java 8 JRE library if not selected by default.
5. Run testng.xml
6. For simplicity, reports are displayed in console itself.
