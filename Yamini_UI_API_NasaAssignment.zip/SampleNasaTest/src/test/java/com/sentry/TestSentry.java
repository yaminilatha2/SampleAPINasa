package com.sentry;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import com.nasasentry.SentryPage;

public class TestSentry {
	WebDriver driver;
	SentryPage sPage;

	@BeforeSuite
	public void launchUrl() {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\yamini\\SampleNasaTest\\chromedriver.exe");

		driver = new ChromeDriver();
		driver.get("https://cneos.jpl.nasa.gov/sentry");
		driver.manage().window().maximize();
	}

	@Test(description = "Monitoring.C001")
	public void testSentryMonitoring() throws Exception {
		sPage = new SentryPage(driver);
		sPage.sentryMonitoring(driver);
	}

	@AfterSuite
	public void closeBrowser() {
		driver.quit();
	}
}
