package com.nasasentry;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

public class SentryPage {
	WebDriver driver;

	By bySelectEntries = By.xpath("//select[@name='riskTable_length']");
	By bysentryTable = By.xpath(("//*[@id='riskTable']"));
	By bysentryCell = By.xpath(("//*[@id='riskTable']/tbody/tr[2]/td[1]"));
	By bystrDynSummary = By.xpath("/html/body/div[6]/div[2]/div[3]/div/table/tbody/tr[1]/td/h4");

	//Constructors
	public SentryPage(WebDriver driver) {

	}

	public void sentryMonitoring(WebDriver driver) throws Exception {
		String[] exp = { "10", "25", "50", "100" };
		int count = 0;

		WebElement selectDrp = driver.findElement(bySelectEntries);
		Select selectEntriesDrp = new Select(selectDrp);

		List<WebElement> drpValues = selectEntriesDrp.getOptions();
		for (WebElement we : drpValues) {
			for (int i = 0; i < exp.length; i++) {
				if (we.getText().equals(exp[i])) {
					count++;
				}
			}
		}
		if (count == exp.length) {
			System.out.println("The select dropdown contains the following values: 10,25,50 & 100");
		} else {
			System.out.println("Select box data is not captured properly");
		}
		Thread.sleep(3000);

		// To get the drop down default selected value
		String defSelVal = selectEntriesDrp.getFirstSelectedOption().getText();
		System.out.println("The default selected value of the dropdown is: " + defSelVal);

		// regarding webtable
		WebElement sentryTable = driver.findElement(bysentryTable);
		WebElement sentryCell = sentryTable.findElement(bysentryCell);
		String sentryCellStr = sentryCell.getText();
		sentryCell.click();
		Thread.sleep(5000);

		String strDynSummary = driver.findElement(bystrDynSummary).getText();
		if (strDynSummary.contains(" ")) {
			strDynSummary = strDynSummary.substring(0, strDynSummary.indexOf(" "));
		}

		if (sentryCellStr.contains(strDynSummary)) {
			System.out.println("we have selected " + sentryCellStr
					+ " in the webtable and is displaying the related page correclty");
		} else {
			System.out.println("Page isnt displayed properly");
		}

	}
}